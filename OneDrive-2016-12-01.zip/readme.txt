- prototype
- no textures

- animations: 45 frames total

	frame 1: neutral pose
	frame 5-20: yellow to blue
	frame 25-40: blue to yellow