5 farbvariationen

- 1 mesh
- keine animationen